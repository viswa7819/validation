// function validateForm() {
//     const username = document.getElementById('username').value;
//     const password = document.getElementById('password').value;

//     if (username.trim() === '') {
//         alert('Please enter your username or email.');
//         return false;
//     }

//     if (password.trim() === '') {
//         alert('Please enter your password.');
//         return false;
//     }

//     alert('Form submitted successfully!');
//     return true;
// }
